# Security Auditor

A professional local security auditing application built in Python. This tool performs static analysis on a target codebase to identify common security vulnerabilities, including hardcoded credentials, SQL injection risks, missing security headers, insecure HTTP references, and unsafe configuration patterns.

## Features

- **Modular architecture** — separate modules for scanning, reporting, and configuration
- **Credential detection** — finds hardcoded API keys, AWS credentials, GitHub tokens, and generic secrets
- **SQL injection detection** — identifies string concatenation, f-string, format(), and % formatting in SQL queries
- **Security header analysis** — checks for missing Content-Security-Policy, X-Frame-Options, and other headers
- **Insecure HTTP detection** — flags non-HTTPS URL references in source and templates
- **Unsafe configuration detection** — flags eval(), exec(), pickle, debug mode, and hardcoded passwords
- **Professional HTML reporting** — color-coded severity levels, code snippets, and remediation advice
- **Automated unit tests** — comprehensive pytest test suite
- **Configurable severity filtering** — report only findings at or above a chosen severity level

## Project Structure

```
security-auditor/
├── auditor/
│   ├── __init__.py          # Package exports
│   ├── config.py            # Configuration, Finding dataclass, Severity enum, pattern definitions
│   ├── scanner_credentials.py  # Hardcoded credential scanner
│   ├── scanner_sqli.py          # SQL injection scanner
│   ├── scanner_headers.py       # Security headers scanner
│   ├── scanner_http.py          # Insecure HTTP scanner
│   ├── scanner_config.py        # Unsafe configuration scanner
│   ├── scanner.py               # Orchestration module
│   ├── reporter.py              # HTML report generator
│   └── cli.py                   # Command-line interface
├── test_site/
│   ├── app.py                  # Deliberately vulnerable Flask application
│   ├── templates/
│   │   └── dashboard.html      # HTML template with missing headers
│   ├── config.yaml             # Config file with hardcoded secrets
│   └── .env                    # Environment file with secrets
├── tests/
│   ├── __init__.py
│   └── test_auditor.py         # Comprehensive pytest test suite
├── requirements.txt
└── README.md
```

## Installation

### Prerequisites

- Python 3.8 or higher
- pip (Python package manager)

### Setup

```bash
cd security-auditor
pip install -r requirements.txt
```

### Requirements

```
pytest>=7.0
flask>=2.0
```

## Usage

### Scan a Directory

```bash
# Scan the current directory and generate a report
python -m auditor.cli .

# Scan a specific directory
python -m auditor.cli /path/to/target

# Save report to a specific location
python -m auditor.cli /path/to/target -o report.html

# Filter by minimum severity (critical, high, medium, low, info)
python -m auditor.cli /path/to/target --severity high

# Enable debug logging
python -m auditor.cli /path/to/target -v
```

### As a Library

```python
from auditor.config import ScanConfig
from auditor.scanner import run_scan
from auditor.reporter import generate_report

config = ScanConfig(target_paths=["/path/to/target"])
findings = run_scan(config)
generate_report(findings, "report.html", "/path/to/target")
```

## Running Tests

```bash
cd security-auditor
pytest tests/ -v
```

## Report Output

The tool generates a professional HTML report with:
- Summary cards showing counts by severity level
- Category breakdown
- Detailed finding table with severity badges, code snippets, and remediation advice
- Dark theme for readability

## Disclaimer

This tool is for **authorized security testing only**. Only scan applications you own or have explicit permission to test. Never use this tool against systems or code you do not own.